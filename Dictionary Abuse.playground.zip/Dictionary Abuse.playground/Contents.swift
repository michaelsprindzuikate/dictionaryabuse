import UIKit
import Foundation

/*
 Basic dictionary usage - all of the values are of the same type
 */
let passwords = ["Steve": "Orange",
                 "Tim": "Apple",
                 "Craig": "Blackberry"]


let stevesLoginCredential = passwords["Steve"]
print(stevesLoginCredential!)

/*
 Less common and not particularly recommended, but you can have dictionaries with mixed types. You just have to generalise them
 by declaring the type as "Any" and then unbox to the specific type intended
 */
let passwords2: [String: Any] = ["Steve": "Orange",
                                 "Tim": 1234,
                                 "Craig": ["laptop": "password1", "desktop": "password2"]]

let timsLoginCredential = passwords2["Tim"] as? Int
print(timsLoginCredential!)


/*
 Of course, you could just wrap the output of the dictionary key into a string to normalise the data.
 */
let passwords3: [String: Any] = ["Steve": "Orange",
                                 "Tim": 1234,
                                 "Craig": ["laptop": "password1", "desktop": "password2"]]

let timsLoginCredentialAsString = "\(String(describing: passwords3["Tim"]!))"
let craigsDesktopCredential = "\(String(describing: (passwords3["Craig"] as? [String: String])!["desktop"]!))"
print(craigsDesktopCredential)

/*
 But don't do this, it's horrible.
 */


/*
 One other thing about dictionaries though is that you're not restricted to using primitives as the value types
 */

struct Password {
    let text: String
    let hint: String
}

let passwords4 = ["Steve": Password(text: "Orange", hint: "something round"),
                  "Tim": Password(text: "Apple", hint: "something....round"),
                  "Craig": Password(text: "Blackberry", hint: "once popular mobile phone maker")]

let craigsCredentials = passwords4["Craig"]
print("Craigs password is \(craigsCredentials!.text) and the hint is \"\(craigsCredentials!.hint)\"")

/*
So a dictionary is just a box that holds other "things" of value, referenced by a key.
 We can give it primitive types (String/Int/Bool) or we can give it structs/classes
 We can also give it closures.

 Here, we typealias a function that takes in no parameters and returns a string

 This isn't a very clever password generator
 */

typealias Generator = () -> String
let passwordGenerator: [String: Generator] = ["Steve": { return "St3v3" },
                        "Tim": { return "C00k."},
                        "Craig": { return "Password1" }]

let stevesGeneratedPassword1 = passwordGenerator["Steve"]!()
print(stevesGeneratedPassword1)


/*
 This can be extended though to have specific behaviour for each key in the dictionary
 */

typealias Generator2 = (String) -> String
let passwordGenerator2: [String: Generator2] = ["Steve": { input in return "\(input.hashValue)" },
                                                "Tim": { input in return String(input.reversed()) },
                                                "Craig": { input in return input.reversed().reversed()}]


let stevesNewPassword = passwordGenerator2["Steve"]!("hello world")
let timsNewPassword = passwordGenerator2["Tim"]!("hello world")
let craigsNewPassword = passwordGenerator2["Craig"]!("hello world")
print(stevesNewPassword)
print(timsNewPassword)
print(craigsNewPassword)


/*
 And since the dictionary just holds values, we could also set the value as a function
 Here, when we grab the value for a key, we call the JokeTeller function that returns a string
 */


struct JokeTeller {
    static func tell() -> String {
        return "What's brown and sticky? A Stick"
    }
}

let jokeListener = ["Steve": JokeTeller.tell(),
                    "Tim": JokeTeller.tell(),
                    "Craig": JokeTeller.tell()]

let stevesJoke = jokeListener["Steve"]!
print(stevesJoke)

/*
 But what if Tim likes rude jokes? Well we can adapt this so that the dictionary passes in a value
 */

struct JokeTeller2 {
    static func tell(rudeOnes: Bool = false) -> String {

        if rudeOnes {
            return "What do you call a **** with a **** *** ****? A ***** "
        }

        return "Why did the chicken cross the road? To get to the other side"
    }
}

let jokeListener2 = ["Steve": JokeTeller2.tell(),
                    "Tim": JokeTeller2.tell(rudeOnes: true),
                    "Craig": JokeTeller2.tell()]

let stevesCleanJoke = jokeListener2["Steve"]!
let timsRudeJoke = jokeListener2["Tim"]!
print(stevesCleanJoke)
print(timsRudeJoke)

/*
 One of the interesting things we can do here, is to use a dictionary to replace branches of logic.

 Take an if-else statment. There, you are taking an assertion and seeing if it evaluates to true.
 And if so, running a block of code.
 One of the downsides of if-else statements is that it requires the compiler to run through each branch to
 make sure that it can evaluate and this takes time and increases complexity the longer an if-else gets.

 What if we were to replace an if-else with a dictionary?
 Where this:
 */


let day = "Monday"

if day == "Monday" {
    print("Weekend over")
} else if day == "Tuesday" {
    print("This week is taking forever")
} else if day == "Wednesday" {
    print("Are you kidding me?")
} else if day == "Thursday" {
    print("End me, please")
} else if day == "Friday" {
    print("Praise be, all is well in the world")
} else {
    print("This weekend will last forever")
}

/*
 Becomes this:
 */

let workDays = ["Monday": "Weekend Over",
                "Tuesday": "This week is taking forever",
                "Wednesday": "Are you kidding me?",
                "Thursday": "End me, please",
                "Friday": "Praise be, all is well in the world"]


if let currentMood = workDays[day] {
    print(currentMood)
} else {
    print("This weekend will last forever")
}

/*
 By moving from an if-else, we have reduced the branches of potential results from six to two.
 Either the Day we want is in the dictionary or it's not and we just have to provide a default behaviour
 */


/*
 Since we can make a dictionary mutable, we're able to add behaviours that can be evaluated later
 */

var devices = ["iPhone": "I use this all the time",
               "iPad": "I use this every day",
               "Apple Watch": "I wear this from morning to bedtime",
               "AppleTV": "I watch Netflix and Disney+ in the evenings"]

let device = devices["AppleTV"]!
print("My AppleTV? \(device)")

devices["HomePod"] = "Errrrr"

print("My Homepod? \(devices["HomePod"]!)")
